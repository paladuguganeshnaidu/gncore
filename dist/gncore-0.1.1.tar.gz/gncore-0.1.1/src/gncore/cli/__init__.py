"""CLI package for GNCore."""
