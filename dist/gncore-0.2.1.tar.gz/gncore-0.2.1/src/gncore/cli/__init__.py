"""CLI package for GNCore."""
